# chrome version

accesses browser apis via `chrome.xxx`

uses background script as service worker rather than script
